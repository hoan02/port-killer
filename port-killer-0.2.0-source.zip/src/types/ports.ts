export interface PortInfo {
  port: number;
  pid: number;
  process_name: string;
  process_path: string;
}



